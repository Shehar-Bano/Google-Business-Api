<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

use Illuminate\Support\Facades\Schedule;

Schedule::command('business:update-places')->daily();
Schedule::command('queue:work --queue=poster-generation,default --stop-when-empty')->everyMinute()->withoutOverlapping();
